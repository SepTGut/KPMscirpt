export const maxDuration = 30

const JSON_HEADERS = {
  'content-type': 'application/json; charset=utf-8',
  'cache-control': 'no-store',
}

function sendResponse(res, isNode, status, data) {
  const body = typeof data === 'string' ? data : JSON.stringify(data)
  if (isNode) {
    res.setHeader('content-type', 'application/json; charset=utf-8')
    res.setHeader('cache-control', 'no-store')
    return res.status(status).send(body)
  }
  return new Response(body, {
    status,
    headers: JSON_HEADERS,
  })
}

function errorResponse(res, isNode, status, message) {
  return sendResponse(res, isNode, status, {
    success: false,
    error: { code: 'PROXY_ERROR', message },
  })
}

export default async function handler(req, res) {
  const isNode = Boolean(res && typeof res.status === 'function')

  // Handle CORS preflight if needed
  if (req.method === 'OPTIONS') {
    if (isNode) {
      res.setHeader('Access-Control-Allow-Origin', '*')
      res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
      res.setHeader('Access-Control-Allow-Headers', 'Content-Type')
      return res.status(204).end()
    }
    return new Response(null, {
      status: 204,
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type',
      },
    })
  }

  const scriptUrl = process.env.GOOGLE_SCRIPT_URL
  if (!scriptUrl) {
    return errorResponse(res, isNode, 500, 'GOOGLE_SCRIPT_URL belum dikonfigurasi di Environment Variables Vercel.')
  }

  // Parse incoming parameters for GET / POST
  let params = new URLSearchParams()
  if (req.method === 'GET') {
    if (req.query && Object.keys(req.query).length > 0) {
      for (const [key, value] of Object.entries(req.query)) {
        if (Array.isArray(value)) {
          value.forEach(v => params.append(key, v))
        } else if (value !== undefined) {
          params.set(key, String(value))
        }
      }
    } else {
      const parsedUrl = new URL(req.url, 'http://localhost')
      params = parsedUrl.searchParams
    }
  } else {
    // POST request
    if (typeof req.body === 'object' && req.body !== null) {
      for (const [key, value] of Object.entries(req.body)) {
        if (value !== undefined) {
          params.set(key, typeof value === 'object' ? JSON.stringify(value) : String(value))
        }
      }
    } else if (typeof req.body === 'string') {
      params = new URLSearchParams(req.body)
    } else if (typeof req.text === 'function') {
      const rawText = await req.text()
      params = new URLSearchParams(rawText)
    }
  }

  const role = params.get('role')
  params.delete('role')

  const token = role === 'admin'
    ? process.env.ADMIN_TOKEN
    : role === 'user'
      ? process.env.DRIVER_TOKEN
      : ''

  if (!token) {
    return errorResponse(res, isNode, 500, `Token role '${role || 'unknown'}' belum dikonfigurasi di Environment Variables Vercel (ADMIN_TOKEN / DRIVER_TOKEN).`)
  }

  params.set('apiToken', token)

  const controller = new AbortController()
  const timeout = setTimeout(() => controller.abort(), 28000)

  try {
    let upstreamUrl = scriptUrl
    const requestOptions = {
      method: req.method === 'GET' ? 'GET' : 'POST',
      signal: controller.signal,
      headers: { 'content-type': 'application/x-www-form-urlencoded' },
    }

    if (req.method === 'GET') {
      const url = new URL(scriptUrl)
      params.forEach((value, key) => url.searchParams.set(key, value))
      upstreamUrl = url.toString()
    } else {
      requestOptions.body = params.toString()
    }

    const upstream = await fetch(upstreamUrl, requestOptions)
    const body = await upstream.text()

    try {
      JSON.parse(body)
    } catch {
      const preview = body.replace(/\s+/g, ' ').trim().slice(0, 160)
      return errorResponse(res, isNode, 502, `Apps Script mengembalikan respons non-JSON (HTTP ${upstream.status}). Periksa deployment Web App, doPost(e), dan izin akses. Cuplikan: ${preview}`)
    }

    return sendResponse(res, isNode, upstream.status, body)
  } catch (error) {
    const message = error?.name === 'AbortError'
      ? 'Permintaan ke Google Apps Script mengalami batas waktu (timeout).'
      : `Tidak dapat terhubung ke Google Apps Script: ${error?.message || error}`
    return errorResponse(res, isNode, 502, message)
  } finally {
    clearTimeout(timeout)
  }
}
